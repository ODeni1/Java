package com.ecommercewebsite.elurre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElurreApplicationTests {

	@Test
	void contextLoads() {
	}

}
