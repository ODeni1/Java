package com.ecommercewebsite.elurre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElurreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElurreApplication.class, args);
	}

}
